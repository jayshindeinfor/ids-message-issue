// node_modules/ids-enterprise-wc/chunks/ids-chunk-ZMMCFAAI.js
var i = Object.defineProperty;
var k = Object.getOwnPropertyDescriptor;
var j = (b) => {
  throw TypeError(b);
};
var l = (b, a, c) => a in b ? i(b, a, {
  enumerable: true,
  configurable: true,
  writable: true,
  value: c
}) : b[a] = c;
var o = (b, a, c, d) => {
  for (var e = d > 1 ? void 0 : d ? k(a, c) : a, f = b.length - 1, g; f >= 0; f--) (g = b[f]) && (e = (d ? g(a, c, e) : g(e)) || e);
  return d && e && i(a, c, e), e;
};
var p = (b, a, c) => l(b, typeof a != "symbol" ? a + "" : a, c);
var h = (b, a, c) => a.has(b) || j("Cannot " + c);
var m = (b, a, c) => (h(b, a, "read from private field"), c ? c.call(b) : a.get(b));
var q = (b, a, c) => a.has(b) ? j("Cannot add the same private member more than once") : a instanceof WeakSet ? a.add(b) : a.set(b, c);
var n = (b, a, c, d) => (h(b, a, "write to private field"), d ? d.call(b, c) : a.set(b, c), c);
var r = (b, a, c) => (h(b, a, "access private method"), c);
var s = (b, a, c, d) => ({
  set _(e) {
    n(b, a, e, c);
  },
  get _() {
    return m(b, a, d);
  }
});

export {
  o,
  p,
  m,
  q,
  n,
  r,
  s
};
//# sourceMappingURL=chunk-XICHCHDX.js.map
