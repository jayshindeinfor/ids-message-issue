import { createRequire } from 'module';const require = createRequire(import.meta.url);
import "./chunk-NQ4HTGF6.js";

// node_modules/ids-enterprise-wc/components/ids-message/ids-message-service.js
var e = class {
  static show(s) {
    let t = document.createElement("ids-message");
    document.body.appendChild(t), t.show(s);
  }
  static hide(s) {
    document.querySelector(`#${s}`)?.hide();
  }
};
export {
  e as default
};
//# sourceMappingURL=ids-enterprise-wc_components_ids-message_ids-message-service.js.map
